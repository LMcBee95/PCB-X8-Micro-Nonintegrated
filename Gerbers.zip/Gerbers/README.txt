Samuel Deghuee
Sdeghuee@gmail.com
(408)693-8003
1/16/2016
STM32f407layout_nonintegrated
X:2.4 Y: 2.8 (inch)
Area: 6.72 inch^2